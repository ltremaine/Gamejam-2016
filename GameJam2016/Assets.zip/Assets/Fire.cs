﻿using UnityEngine;
using System.Collections;

public class Fire : MonoBehaviour {

	void OnMouseDown()
    {
        Debug.Log("Fire");
	
	}
}
