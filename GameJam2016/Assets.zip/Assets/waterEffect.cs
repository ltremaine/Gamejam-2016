﻿using UnityEngine;
using System.Collections;

public class waterEffect : MonoBehaviour
{
    void OnMouseDown()
    {
        Debug.Log ("Water");
    }

}
