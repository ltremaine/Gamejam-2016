﻿using UnityEngine;
using System.Collections;

public class Heal : MonoBehaviour
{
    void OnMouseDown()
    {
        Debug.Log("Heal");
    }

}