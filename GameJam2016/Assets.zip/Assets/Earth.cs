﻿using UnityEngine;
using System.Collections;

public class Earth : MonoBehaviour 
{
    void OnMouseDown()
    {
        Debug.Log("Earth");
    }
	
}
